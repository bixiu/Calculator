package cn.ztcaoll222.cn.Calculator.CalculatorGui.impl;

import cn.ztcaoll222.cn.Calculator.CalculatorGui.iCalculatorGui;
import cn.ztcaoll222.cn.Calculator.CalculatorServer.iCalculatorServer;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class CalculatorGuiImpl implements iCalculatorGui {
    private JFrame frame;
    private JTextField textField;

    private JButton btn_clear;
    private JButton btn_del;

    private JButton btn_0;
    private JButton btn_1;
    private JButton btn_2;
    private JButton btn_3;
    private JButton btn_4;
    private JButton btn_5;
    private JButton btn_6;
    private JButton btn_7;
    private JButton btn_8;
    private JButton btn_9;

    private JButton btn_dot;

    private JButton btn_plus;
    private JButton btn_jian;
    private JButton btn_cheng;
    private JButton btn_chu;

    private JButton btn_l;
    private JButton btn_r;

    private JButton btn_equal;

    private JPanel pan;
    private JPanel pan2;

    private iCalculatorServer m_calculatorServer;

    public CalculatorGuiImpl() {
        pan = new JPanel();
        pan2 = new JPanel();
        frame = new JFrame("Calculator");
        textField = new JTextField(20);
        btn_clear = new JButton("C");
        btn_del = new JButton("Del");
        btn_0 = new JButton("0");
        btn_1 = new JButton("1");
        btn_2 = new JButton("2");
        btn_3 = new JButton("3");
        btn_4 = new JButton("4");
        btn_5 = new JButton("5");
        btn_6 = new JButton("6");
        btn_7 = new JButton("7");
        btn_8 = new JButton("8");
        btn_9 = new JButton("9");
        btn_dot = new JButton(".");
        btn_plus = new JButton("+");
        btn_jian = new JButton("-");
        btn_cheng = new JButton("*");
        btn_chu = new JButton("/");
        btn_l = new JButton("(");
        btn_r = new JButton(")");
        btn_equal = new JButton("=");
    }

    @Override
    public void init() {
        btn_clear.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (textField.getText().length() > 0) {
                    textField.setText("");
                }
            }
        });
        btn_del.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (textField.getText().length() > 0) {
                    textField.setText( textField.getText().substring(0, textField.getText().length()-1) );
                }
            }
        });
        btn_0.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_0.getText());
            }
        });
        btn_1.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_1.getText());
            }
        });
        btn_2.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_2.getText());
            }
        });
        btn_3.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_3.getText());
            }
        });
        btn_4.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_4.getText());
            }
        });
        btn_5.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_5.getText());
            }
        });
        btn_6.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_6.getText());
            }
        });
        btn_7.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_7.getText());
            }
        });
        btn_8.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_8.getText());
            }
        });
        btn_9.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_9.getText());
            }
        });
        btn_dot.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_dot.getText());
            }
        });
        btn_plus.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_plus.getText());
            }
        });
        btn_jian.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_jian.getText());
            }
        });
        btn_cheng.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_cheng.getText());
            }
        });
        btn_chu.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_chu.getText());
            }
        });
        btn_l.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_l.getText());
            }
        });
        btn_r.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textField.setText(textField.getText()+btn_r.getText());
            }
        });
        btn_equal.addActionListener(new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                m_calculatorServer.in(textField.getText());
                m_calculatorServer.cal();
                textField.setText(m_calculatorServer.out());
            }
        });
    }


    @Override
    public void show() {
        textField.setEditable(false);

        pan.setLayout(new GridLayout(5, 4, 5, 5));
        pan.add(btn_l);
        pan.add(btn_r);
        pan.add(btn_cheng);
        pan.add(btn_chu);

        pan.add(btn_7);
        pan.add(btn_8);
        pan.add(btn_9);
        pan.add(btn_plus);

        pan.add(btn_4);
        pan.add(btn_5);
        pan.add(btn_6);
        pan.add(btn_jian);

        pan.add(btn_1);
        pan.add(btn_2);
        pan.add(btn_3);
        pan.add(btn_clear);

        pan.add(btn_0);
        pan.add(btn_dot);
        pan.add(btn_del);
        pan.add(btn_equal);

        pan.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        pan2.setLayout(new BorderLayout());
        pan2.add(textField);

        frame.setLocation(300, 200);
        frame.setResizable(false);
        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(pan2, BorderLayout.NORTH);
        frame.getContentPane().add(pan, BorderLayout.CENTER);

        frame.pack();
        frame.setVisible(true);
    }

    @Override
    public void setCalculatorServer(iCalculatorServer calculatorServer) {
        m_calculatorServer = calculatorServer;
    }
}
