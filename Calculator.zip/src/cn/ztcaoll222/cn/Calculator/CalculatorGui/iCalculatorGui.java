package cn.ztcaoll222.cn.Calculator.CalculatorGui;

import cn.ztcaoll222.cn.Calculator.CalculatorServer.iCalculatorServer;

public interface iCalculatorGui {
    void init();
    void setCalculatorServer(iCalculatorServer calculatorServer);
    void show();
}
