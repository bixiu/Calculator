package cn.ztcaoll222.cn.Calculator.CalculatorServer;

public interface iCalculatorServer {
    void in(String str);
    void cal();
    String out();
}
