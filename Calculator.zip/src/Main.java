import cn.ztcaoll222.cn.Calculator.CalculatorGui.iCalculatorGui;
import cn.ztcaoll222.cn.Calculator.CalculatorGui.impl.CalculatorGuiImpl;
import cn.ztcaoll222.cn.Calculator.CalculatorServer.impl.CalculatorServer;

public class Main {
    public static void main(String[] args) {
        iCalculatorGui calculatorGui = new CalculatorGuiImpl();
        calculatorGui.init();
        calculatorGui.setCalculatorServer(new CalculatorServer());
        calculatorGui.show();
    }
}
